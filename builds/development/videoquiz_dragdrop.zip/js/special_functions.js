//alert ("hej!");

function etheltspecieltfunktionsnavn(){
	//alert("is working");
}